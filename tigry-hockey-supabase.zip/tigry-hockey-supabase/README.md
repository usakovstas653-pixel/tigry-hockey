# Тигры — школьная хоккейная команда

Next.js + Supabase, готово для Vercel.

1. Выполнить `supabase/schema.sql` в Supabase SQL Editor.
2. В Vercel добавить переменные из `.env.example`.
3. Реальный пароль администратора не хранить в GitHub.
