import crypto from "crypto"; import {cookies} from "next/headers";
const name="tigry_admin"; const secret=()=>process.env.SESSION_SECRET||"change-me";
const sign=(s:string)=>crypto.createHmac("sha256",secret()).update(s).digest("hex");
export function token(){const exp=Math.floor(Date.now()/1000)+60*60*24*30;return `${exp}.${sign(String(exp))}`}
export async function isAdmin(){const v=(await cookies()).get(name)?.value;if(!v)return false;const [e,s]=v.split(".");if(!e||!s||Number(e)<Date.now()/1000)return false;return crypto.timingSafeEqual(Buffer.from(s),Buffer.from(sign(e)))}
export {name};
