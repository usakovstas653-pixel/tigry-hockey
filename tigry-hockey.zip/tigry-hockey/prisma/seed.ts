import { PrismaClient, PlayerPosition, MatchStatus, MatchVenue, NewsStatus, GalleryCategory } from "@prisma/client";
import bcrypt from "bcryptjs";
const prisma = new PrismaClient();
async function main() {
  const email = process.env.ADMIN_EMAIL || "admin@tigry.local";
  const password = process.env.ADMIN_PASSWORD || "change-me";
  await prisma.user.upsert({ where: { email }, update: {}, create: { email, passwordHash: await bcrypt.hash(password, 12) } });
  await prisma.siteSettings.upsert({ where: { id: 1 }, update: {}, create: {} });
  if ((await prisma.player.count()) === 0) {
    await prisma.player.createMany({ data: [
      { firstName: "Иван", lastName: "Иванов", number: 10, position: PlayerPosition.FORWARD, description: "Энергичный нападающий команды." },
      { firstName: "Максим", lastName: "Петров", number: 1, position: PlayerPosition.GOALIE, description: "Надёжный вратарь «Тигров»." },
      { firstName: "Алексей", lastName: "Соколов", number: 4, position: PlayerPosition.DEFENDER, description: "Защитник с командным характером." }
    ] });
  }
  if ((await prisma.match.count()) === 0) {
    const d = new Date(); d.setDate(d.getDate() + 7); d.setHours(18, 0, 0, 0);
    await prisma.match.create({ data: { opponent: "Сокол", date: d, time: "18:00", place: "Школьная ледовая арена", venue: MatchVenue.HOME, status: MatchStatus.UPCOMING } });
    const past = new Date(); past.setDate(past.getDate() - 5); past.setHours(18, 0, 0, 0);
    await prisma.match.create({ data: { opponent: "Метеор", date: past, time: "18:00", place: "Городская арена", venue: MatchVenue.AWAY, status: MatchStatus.FINISHED, homeScore: 5, awayScore: 3 } });
  }
  if ((await prisma.news.count()) === 0) await prisma.news.create({ data: { title: "Тигры открывают новый сезон", text: "Команда начинает сезон с тренировок и подготовки к первым матчам.", status: NewsStatus.PUBLISHED } });
  if ((await prisma.gallery.count()) === 0) await prisma.gallery.create({ data: { image: "/images/tiger-placeholder.svg", description: "Команда «Тигры»", category: GalleryCategory.TEAM } });
}
main().finally(() => prisma.$disconnect());
