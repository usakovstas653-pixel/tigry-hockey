import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: { tiger: "#f97316", ink: "#090909", coal: "#171717", smoke: "#a3a3a3" },
      boxShadow: { glow: "0 0 45px rgba(249,115,22,.22)" }
    }
  },
  plugins: []
};
export default config;
