export const positionLabel = { GOALIE: "Вратарь", DEFENDER: "Защитник", FORWARD: "Нападающий" } as const;
export const venueLabel = { HOME: "Домашний", AWAY: "Выездной" } as const;
export const categoryLabel = { MATCH: "Матчи", TRAINING: "Тренировки", TEAM: "Команда", TOURNAMENT: "Турниры", FANS: "Болельщики" } as const;
export function dateRu(d: Date | string) { return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", year: "numeric" }).format(new Date(d)); }
export function shortDate(d: Date | string) { return new Intl.DateTimeFormat("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" }).format(new Date(d)); }
