import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
const secret = new TextEncoder().encode(process.env.AUTH_SECRET || "development-secret-change-me");
export async function createSession(userId: string) { return new SignJWT({ userId }).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("7d").sign(secret); }
export async function getSession() { const token = (await cookies()).get("tigry_session")?.value; if (!token) return null; try { return await jwtVerify(token, secret); } catch { return null; } }
export async function requireAdmin() { const session = await getSession(); if (!session) throw new Error("UNAUTHORIZED"); return String(session.payload.userId); }
