import "./globals.css"; import Header from "@/components/Header"; import Footer from "@/components/Footer";
export const metadata = { title: "Тигры — школьная хоккейная команда", description: "Сила. Скорость. Команда." };
export default function RootLayout({children}:{children:React.ReactNode}){return <><Header/><main>{children}</main><Footer/></>}
