import { NextResponse } from "next/server"; import { db } from "@/lib/db"; import { requireAdmin } from "@/lib/auth";
function data(b:any){return {title:b.title,image:b.image||null,text:b.text,date:new Date(b.date),status:b.status}}
export async function POST(req:Request){try{await requireAdmin();return NextResponse.json(await db.news.create({data:data(await req.json())}))}catch(e:any){return NextResponse.json({error:e.message},{status:400})}}
export async function PUT(req:Request){try{await requireAdmin();const b=await req.json();return NextResponse.json(await db.news.update({where:{id:b.id},data:data(b)}))}catch(e:any){return NextResponse.json({error:e.message},{status:400})}}
export async function DELETE(req:Request){try{await requireAdmin();const {id}=await req.json();await db.news.delete({where:{id}});return NextResponse.json({ok:true})}catch(e:any){return NextResponse.json({error:e.message},{status:400})}}
